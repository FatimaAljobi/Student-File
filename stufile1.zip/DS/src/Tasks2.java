
import java.util.Random;

/**
 * Created by Fatima on 10/02/2021.
 */
public class Tasks2 {

    int []a={10,20,30,40,50};
    int []b=new int[5];
    int num=0;

    public void Reverse(){
        num=a.length-1;
        for(int i=0; i<a.length;i++){
            b[num]=a[i];
            num--;
        }

    }

    public void backup(){
        for(int i =0;i<a.length;i++){
            b[i]=a[i];
        }
        System.out.println("backup is done");
    }

    public void removing(int index){
        int[] copy = new int[a.length - 1];
        for (int i = 0, j = 0; i < a.length; i++) {
            if (i != index) {
                copy[j++] = a[i];
            }
        }
            System.out.println("removing is done");
            for (int i = 0; i < a.length - 1; i++) {
                System.out.println(copy[i]);
            }
        }



     public void removeElements(){
        Random r = new Random();
        while (a.length > 0) {
            int index = r.nextInt(a.length);
            System.out.println("INDEX = " + index + ", ELEMENT = " + a[index]);
            int[] array = new int[a.length - 1];
            for (int i = 0; i < index; i++)
                array[i] = a[i];
            for (int i = index; i < a.length - 1; i++)
                array[i] = a[i + 1];
            a = array;
        }

        System.out.println("removing is done");
         for (int i = 0; i < a.length - 1; i++) {
             System.out.println(a[i]);
         }
    }

    public void print(){
        System.out.println(" array a:");
        for (int i=0;i<a.length;i++) {
            System.out.println(a[i]);
        }
        System.out.println(" array b:");
        for (int i=0;i<b.length;i++) {
        System.out.println(b[i]);
        }
    }

    public static void main(String[] args) {
        Tasks2 t=new Tasks2();

        /*t.Reverse();
        t.print();*/

        /*t.backup();
        t.print();*/

        //t.removing(3);

        t.removeElements();
    }
}
