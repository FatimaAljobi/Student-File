import java.util.Scanner;

/**
 * Created by Fatima on 03/02/2021.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World !");

        int i=3;
        System.out.println(i);

        int s[]={1,2,3,4};
        System.out.println(s);

        for(int l=0;l<s.length;l++)
        {
            System.out.println(s[l]);
        }

        Scanner m=new Scanner(System.in);

        int k[]=new int[5];

        for(int l=0;l<s.length;l++)
        {
            k[l]=m.nextInt();
        }

        System.out.println("[");

        for(int l=0;l<s.length;l++)
        {
            if(l==s.length-1)
                System.out.println(k[l]);
            else
                System.out.println(k[l]+",");
        }

        System.out.println("]");

    }
}
