/**
 * Created by Fatima on 10/02/2021.
 */
public class Exercises {
    int []a={10,20,30,40,50,60,70,80,90,100};
    int []b={1,2,3,4,5,6,7,8,9,10};

    public void search(int num) {

        boolean s=false;
        int m=0;

        for (int i = 0; i < a.length; i++) {

            if (a[i] == num){
                s=true;
                m=i;
            }

        }
            if (s==true) {
                System.out.println("the num " + num + " is found in index:" + m);
            }
            else
                {
                System.out.println("the num " + num + " is not found in the array!");
            }

    }

   public void merging() {
       int[] c = new int[a.length + b.length];
       for (int i = 0, j = 0; i < c.length; i += 2) {
           c[i] = a[j];
           c[i + 1] = b[j];
           j++;
       }

       System.out.println("merging array: ");

       for (int i = 0; i < c.length; i++) {
           if(i==c.length-1)
                System.out.print(c[i]);
           else
                System.out.print(c[i]+" , ");
       }

   }


    public static void main(String[] args) {
        Exercises e=new Exercises();

        e.search(30);

        e.merging();
    }
}

