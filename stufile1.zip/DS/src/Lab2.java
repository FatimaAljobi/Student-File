import java.util.Scanner;
/**
 * Created by Fatima on 03/02/2021.
 */
public class Lab2 {

    int a[]={11,12,13,14,15};
    int s[]=new int[5];
    int num=0;

    public void reverse()
    {
        int n= a.length-1;
        for(int i=0;i<a.length/2;i++){
            int t= a[i];
            a[i]=a[n];
            a[n]=t;
            n--;
        }

    }

    public void shiftright(){
        int i ;
        for (i = a.length-1 ; i>0 ; i--) {
            a[i]=a[i-1];
        }
        a[i]=0;
    }


    public void shiftleft(){
        int i ;
        for (i =0 ; i<a.length-1 ; i++) {
            a[i]=a[i+1];
        }
        a[i]=0;
    }

    public void add(int newE){
        if(num<s.length){s[num++]=newE;}

        else
            System.out.println("Array is full!");

    }

    public void addsort(int newE){
        if (num<s.length){
            num++;
            int i=num-1;
            while (i>0&&s[i-1]>newE)
            {
                s[i]=s[i-1];
                i--;
            }
            s[i]=newE;
        }
        else
            System.out.println("Array is full!");

    }

    public void print(){
        System.out.print("[");
        for (int i=0;i<s.length;i++)
        {
            if(i==s.length-1)
                System.out.print(s[i]);
            else
                System.out.print(s[i]+",");
        }
        System.out.println("]");
    }

    public static void main(String[] args) {

        Lab2 o=new Lab2();
        Scanner m=new Scanner(System.in);


        /*o.print();
        o.reverse();
        o.print();*/

        /*o.print();
        o.shiftright();
        o.print();*/

        /*o.print();
        o.shiftleft();
        o.print();*/

        /*o.print();
        while(true){
            o.add(m.nextInt());
            o.print();
        }*/

        o.print();
        while(true){
            o.addsort(m.nextInt());
            o.print();
        }

}

}

